#ifndef H_PARTA
#define H_PARTA
struct Game;
void ChooseW(struct Game **p, int b);
#endif
