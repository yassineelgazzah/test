#ifndef H_CHOOSEW
#define H_CHOOSEW
struct Game;
void ChooseW(struct Game **p, int b);
int Totem( struct Game **pa,struct  Game **pb, int c, struct Game **pd, int g, int h);
#endif

