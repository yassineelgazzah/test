#ifndef H_PART1
#define H_PART1
struct Game;
void ChooseW(struct Game **p, int b);
#endif
