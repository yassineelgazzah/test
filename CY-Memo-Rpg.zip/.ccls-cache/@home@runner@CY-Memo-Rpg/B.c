#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct {
  int type;
  int weapon;
  int class;
  int lab;
  int loot;
  int item1;
  int item2;
  char name[20];
}Game;

int Move(Game **pa, Game **pb, int c, int a, int b, Game **pd) {
  int e = 0;
  int d = 0;
  for (int i = 0; i < 7; i++) {
    if (d == 1) {
      break;
    }
    for (int j = 0; j < 7; j++) {
      if (d == 1) {
        break;
      }
      if ((*(*(pb + i) + j)).type == 1) {
        if ((*(*(pb + i) + j)).class == c) {
          d = 1;
          ChooseW(pb, c);
          if ((*(*(pa + a) + b)).type == 0) {
            printf("Impossible");
          }
          if ((*(*(pa + a) + b)).type == 1) {
            printf("Impossible");
          }
          if ((*(*(pa + a) + b)).type == 5) {
            (*(*(pb + a) + b)) = (*(*(pb + i) + j));
            (*(*(pa + a) + b)) = (*(*(pb + i) + j));
            (*(*(pb + i) + j)).type = 5;
            (*(*(pa + i) + j)).type = 5;
          }
          if ((*(*(pa + a) + b)).type == 3) {
            if ((*(*(pa + a) + b)).lab == 1) {
              if ((*(*(pb + i) + j)).weapon == 2) {
                printf("A Basilisk has been defeated\n");
                (*(*(pb + a) + b)) = (*(*(pb + i) + j));
                (*(*(pa + a) + b)) = (*(*(pb + i) + j));
                (*(*(pb + i) + j)).type = 5;
                (*(*(pa + i) + j)).type = 5;

              } else {
                printf("A Basilisk defeated you\n");
                e = 1;
              }
            }
            if ((*(*(pa + a) + b)).lab == 2) {
              if ((*(*(pb + i) + j)).weapon == 3) {
                printf("A Troll has been defeated\n");
                (*(*(pb + a) + b)) = (*(*(pb + i) + j));
                (*(*(pa + a) + b)) = (*(*(pb + i) + j));
                (*(*(pb + i) + j)).type = 5;
                (*(*(pa + i) + j)).type = 5;

              } else {
                printf("A Troll defeated you\n");
                e = 1;
              }
            }
            if ((*(*(pa + a) + b)).lab == 4) {
              if ((*(*(pb + i) + j)).weapon == 1) {
                printf("A Zombie has been defeated\n");
                (*(*(pb + a) + b)) = (*(*(pb + i) + j));
                (*(*(pa + a) + b)) = (*(*(pb + i) + j));
                (*(*(pb + i) + j)).type = 5;
                (*(*(pa + i) + j)).type = 5;

              } else {
                printf("A Zombie defeated you\n");
                e = 1;
              }
            }
            if ((*(*(pa + a) + b)).lab == 5) {
              if ((*(*(pb + i) + j)).weapon == 4) {
                printf("A Harpy has been defeated\n");
                (*(*(pb + a) + b)) = (*(*(pb + i) + j));
                (*(*(pa + a) + b)) = (*(*(pb + i) + j));
                (*(*(pb + i) + j)).type = 5;
                (*(*(pa + i) + j)).type = 5;
              } else {
                printf("A Harpy defeated you\n");
                e = 1;
              }
            }
            if ((*(*(pa + a) + b)).lab == 3) {
              e = Teleport(pa, pb, c, pd);
              (*(*(pb + a) + b)).type = 5;
              (*(*(pa + a) + b)).type = 5;
            }
            if ((*(*(pa + a) + b)).lab == 6) {
              e = Totem(pa, pb, c, pd, a, b);
            }
          }
          if ((*(*(pa + a) + b)).type == 4) {
            if ((*(*(pa + a) + b)).loot == 1) {
              printf("You found the Pet Control Stick\n");
              if ((*(*(pb + i) + j)).class == 1) {
                (*(*(pb + i) + j)).item1 = 1;
              }
              (*(*(pb + a) + b)) = (*(*(pb + i) + j));
              (*(*(pa + a) + b)) = (*(*(pb + i) + j));
              (*(*(pb + i) + j)).type = 5;
              (*(*(pa + i) + j)).type = 5;
            }
            if ((*(*(pa + a) + b)).loot == 2) {
              printf("You found the Sleep Dagger\n");
              if ((*(*(pb + i) + j)).class == 3) {
                (*(*(pb + i) + j)).item1 = 1;
              }
              (*(*(pb + a) + b)) = (*(*(pb + i) + j));
              (*(*(pa + a) + b)) = (*(*(pb + i) + j));
              (*(*(pb + i) + j)).type = 5;
              (*(*(pa + i) + j)).type = 5;
            }
            if ((*(*(pa + a) + b)).loot == 3) {
              printf("You found the Fire Sword\n");
              if ((*(*(pb + i) + j)).class == 2) {
                (*(*(pb + i) + j)).item1 = 1;
              }
              (*(*(pb + a) + b)) = (*(*(pb + i) + j));
              (*(*(pa + a) + b)) = (*(*(pb + i) + j));
              (*(*(pb + i) + j)).type = 5;
              (*(*(pa + i) + j)).type = 5;
            }
            if ((*(*(pa + a) + b)).loot == 4) {
              printf("You found the Forbidden Grimoire\n");
              if ((*(*(pb + i) + j)).class == 4) {
                (*(*(pb + i) + j)).item1 = 1;
              }
              (*(*(pb + a) + b)) = (*(*(pb + i) + j));
              (*(*(pa + a) + b)) = (*(*(pb + i) + j));
              (*(*(pb + i) + j)).type = 5;
              (*(*(pa + i) + j)).type = 5;
            }
            if ((*(*(pa + a) + b)).loot == 5) {
              printf("You found a Treasure\n");
              (*(*(pb + i) + j)).item2 = 1;
              (*(*(pb + a) + b)) = (*(*(pb + i) + j));
              (*(*(pa + a) + b)) = (*(*(pb + i) + j));
              (*(*(pb + i) + j)).type = 5;
              (*(*(pa + i) + j)).type = 5;
            }
          }
        }
      }
    }
  }
  return e;
}

int MoveD( Game **pa, Game **pb, Game **pd, int c) {
  int d, e, f;
  e = 0;
  f = 0;
  printf("Now choose your direction:\n           Up\n           [1]\nLeft [4]  "
         "        Right [2]\n           [3]\n           Down\n");
  scanf("%d", &d);
  while (d > 4 || d < 1) {
    printf("Impossible\n");
    printf("Now choose your direction:\n           Up\n           [1]\nLeft "
           "[4]          Right [2]\n           [3]\n           Down\n");
    scanf("%d", &d);
  }
  for (int i = 0; i < 7; i++) {
    if (f == 1) {
      break;
    }
    for (int j = 0; j < 7; j++) {
      if (f == 1) {
        break;
      }
      if ((*(*(pb + i) + j)).type == 1) {
        if ((*(*(pb + i) + j)).class == c) {
          f = 1;
          if (d == 1) {
            e = Move(pa, pb, c, i - 1, j, pd);
          }
          if (d == 2) {
            e = Move(pa, pb, c, i, j + 1, pd);
          }
          if (d == 3) {
            e = Move(pa, pb, c, i + 1, j, pd);
          }
          if (d == 4) {
            e = Move(pa, pb, c, i, j - 1, pd);
          }
        }
      }
    }
  }
  return e;
}

int FirstMove( Game **pa, Game **pb, Game **pd, int c) {
  int a, e, d;
  e = 0;
  d = 0;
  printf("Now choose your direction:\n           Up\n           [1]\nLeft [4]  "
         "        Right [2]\n           [3]\n           Down\n");
  scanf("%d", &a);
  for (int i = 0; i < 7; i++) {
    if (d == 1) {
      break;
    }
    for (int j = 0; j < 7; j++) {
      if (d == 1) {
        break;
      }
      if ((*(*(pb + i) + j)).type == 1) {
        if ((*(*(pb + i) + j)).class == c) {
          d = 1;
          if (c == 1) {
            while (a != 3) {
              printf("Impossible\n");
              printf("Now choose your direction:\n           Up\n           "
                     "[1]\nLeft [4]          Right [2]\n           [3]\n       "
                     "    Down\n");
              scanf("%d", &a);
            }
            e = Move(pa, pb, c, i + 1, j, pd);
            (*(*(pb + i) + j)).type = 0;
            (*(*(pa + i) + j)).type = 0;
          }
          if (c == 2) {
            while (a != 2) {
              printf("Impossible\n");
              printf("Now choose your direction:\n           Up\n           "
                     "[1]\nLeft [4]          Right [2]\n           [3]\n       "
                     "    Down\n");
              scanf("%d", &a);
            }
            e = Move(pa, pb, c, i, j + 1, pd);
            (*(*(pb + i) + j)).type = 0;
            (*(*(pa + i) + j)).type = 0;
          }
          if (c == 3) {
            while (a != 1) {
              printf("Impossible\n");
              printf("Now choose your direction:\n           Up\n           "
                     "[1]\nLeft [4]          Right [2]\n           [3]\n       "
                     "    Down\n");
              scanf("%d", &a);
            }
            e = Move(pa, pb, c, i - 1, j, pd);
            (*(*(pb + i) + j)).type = 0;
            (*(*(pa + i) + j)).type = 0;
          }
          if (c == 4) {
            while (a != 4) {
              printf("Impossible\n");
              printf("Now choose your direction:\n           Up\n           "
                     "[1]\nLeft [4]          Right [2]\n           [3]\n       "
                     "    Down\n");
              scanf("%d", &a);
            }
            e = Move(pa, pb, c, i, j - 1, pd);
            (*(*(pb + i) + j)).type = 0;
            (*(*(pa + i) + j)).type = 0;
          }
        }
      }
    }
  }
  return e;
}