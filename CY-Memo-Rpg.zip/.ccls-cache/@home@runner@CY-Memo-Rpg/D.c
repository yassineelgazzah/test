#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct {
  int type;
  int weapon;
  int class;
  int lab;
  int loot;
  int item1;
  int item2;
  char name[20];
}Game;

void print( Game **p) {
  printf(
      "\n----------------------------------------------------------------\n");
  printf("        ");
  for (int i = 0; i < 7; i++) {
    for (int j = 0; j < 7; j++) {
      if ((*(*(p + i) + j)).type == 1) {
        printf(" %s ", (*(*(p + i) + j)).name);
      }
    }
  }
  printf("\n----------------------------------------------------------------");
  printf("\n\n");
  for (int i = 0; i < 7; i++) {
    printf("          ");
    for (int j = 0; j < 7; j++) {
      if ((*(*(p + i) + j)).type == 2) {
        printf(" o ");
      } else {
        if ((*(*(p + i) + j)).type == 1) {
          if ((*(*(p + i) + j)).class == 1) {
            printf(" R ");
          }
          if ((*(*(p + i) + j)).class == 2) {
            printf(" G ");
          }
          if ((*(*(p + i) + j)).class == 3) {
            printf(" V ");
          }
          if ((*(*(p + i) + j)).class == 4) {
            printf(" M ");
          }
        } else {
          if ((*(*(p + i) + j)).type == 0) {
            printf("   ");
          } else {
            if ((*(*(p + i) + j)).type == 3) {
              if ((*(*(p + i) + j)).lab == 1) {
                printf(" B ");
              } else {
                if ((*(*(p + i) + j)).lab == 2) {
                  printf(" T ");
                } else {
                  if ((*(*(p + i) + j)).lab == 3) {
                    printf(" P ");
                  } else {
                    if ((*(*(p + i) + j)).lab == 4) {
                      printf(" Z ");
                    } else {
                      if ((*(*(p + i) + j)).lab == 5) {
                        printf(" H ");
                      } else {
                        if ((*(*(p + i) + j)).lab == 6) {
                          printf(" O ");
                        }
                      }
                    }
                  }
                }
              }
            } else {
              if ((*(*(p + i) + j)).type == 4) {
                if ((*(*(p + i) + j)).loot == 1) {
                  printf(" 1 ");
                } else {
                  if ((*(*(p + i) + j)).loot == 2) {
                    printf(" 2 ");
                  } else {
                    if ((*(*(p + i) + j)).loot == 3) {
                      printf(" 3 ");
                    } else {
                      if ((*(*(p + i) + j)).loot == 4) {
                        printf(" 4 ");
                      } else {
                        if ((*(*(p + i) + j)).loot == 5) {
                          printf(" 5 ");
                        }
                      }
                    }
                  }
                }
              } else {
                if ((*(*(p + i) + j)).type == 5) {
                  printf("   ");
                }
              }
            }
          }
        }
      }
    }
    printf("\n");
  }
}

void Rule() {
  printf("\n");
  printf("----------------------------------------------------------------\n");
  printf("----------------------------------------------------------------\n");
  printf("The goal of the game is to find its ancient weapon and a braid by "
         "facing the dangers of the Labyrinth\n");
  printf("----------------------------------------------------------------\n");
  printf("-Loot\n");
  printf("|[1] Stick        [2] Dagger     |\n");
  printf("|[3] Sword        [4] Grimoire   |\n");
  printf("|[5] Treasure                    |\n");
  printf("----------------------------------------------------------------\n");
  printf("-The Ranger seeks the Pet Control Stick\n");
  printf("-The Warrior seeks the Fire Sword\n");
  printf("-The Wizard seeks the Forbidden Grimoire\n");
  printf("-The Thief seeks the Sleep Dagger\n");
  printf("----------------------------------------------------------------\n");
  printf("-Player\n");
  printf("|[R] Ranger      [G] Warrior|\n");
  printf("|[M] Wizard      [V] Thief  |\n");
  printf("----------------------------------------------------------------\n");
  printf("-Monster\n");
  printf("|[Z] Zombie      [H] Harpy   |\n");
  printf("|[T] Troll       [B] Basilisk|\n");
  printf("----------------------------------------------------------------\n");
  printf("-To defeat the Zombie use the Torch\n");
  printf("-To defeat the Troll use the Axe\n");
  printf("-To defeat the Harpy use the Bow\n");
  printf("-To defeat the Basilisk use the Schield\n");
  printf("----------------------------------------------------------------\n");
  printf("-Labyrinth\n");
  printf("|[P] Portal      [O] Totem|\n");
  printf("----------------------------------------------------------------\n");
  printf("-The Portal allows you to teleport sur la carte\n");
  printf("-The Totem allows you to swap two cases\n");
  printf("----------------------------------------------------------------\n");
  printf("----------------------------------------------------------------\n");
  printf("\n");
}

int Menu( Game **p) {
  int a;
  a = 0;
  printf("Welcome to Cy-Memo-RPG:\n");
  printf("Select the number of players between 2 and 4:\n");
  scanf("%d", &a);
  while (a > 4 || a < 2) {
    printf("Impossible\n");
    printf("Select the number of players between 2 and 4:\n");
    scanf("%d", &a);
  }
  if (a == 2) {
    printf("Player 1 you are the Ranger:\n");
    printf("Give your name:\n");
    scanf("%s", (*(*p + 4)).name);
    printf("Player 2 you are the Warrior:\n");
    printf("Give your name:\n");
    scanf("%s", (*(*(p + 2))).name);
  }
  if (a == 3) {
    printf("Player 1 you are the Ranger:\n");
    printf("Give your name:\n");
    scanf("%s", (*(*p + 4)).name);
    printf("Player 2 you are the Warrior:\n");
    printf("Give your name:\n");
    scanf("%s", (*(*(p + 2))).name);
    printf("Player 3 you are the Thief:\n");
    printf("Give your name:\n");
    scanf("%s", (*(*(p + 6) + 2)).name);
  }
  if (a == 4) {
    printf("Player 1 you are the Ranger:\n");
    printf("Give your name:\n");
    scanf("%s", (*(*p + 4)).name);
    printf("Player 2 you are the Warrior:\n");
    printf("Give your name:\n");
    scanf("%s", (*(*(p + 2))).name);
    printf("Player 3 you are the Thief:\n");
    printf("Give your name:\n");
    scanf("%s", (*(*(p + 6) + 2)).name);
    printf("Player 4 you are the Wizard:\n");
    printf("Give your name:\n");
    scanf("%s", (*(*(p + 4) + 6)).name);
  }
  return a;
}
void FillName( Game **p,  Game **pa, int a, int b) {
  for (int i = 0; i < 20; i++) {
    (*(*(p + a) + b)).name[i] = (*(*(pa + a) + b)).name[i];
  }
}

void SamePlayer( Game **p, int a,  Game **pa) {
  if (a == 2) {
    FillName(p, pa, 0, 4);
    FillName(p, pa, 2, 0);
  }
  if (a == 3) {
    FillName(p, pa, 0, 4);
    FillName(p, pa, 2, 0);
    FillName(p, pa, 6, 2);
  }
  if (a == 4) {
    FillName(p, pa, 0, 4);
    FillName(p, pa, 2, 0);
    FillName(p, pa, 6, 2);
    FillName(p, pa, 4, 6);
  }
}