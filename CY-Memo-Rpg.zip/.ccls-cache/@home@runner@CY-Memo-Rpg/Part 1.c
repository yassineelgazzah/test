#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct {
  int type;
  int weapon;
  int class;
  int lab;
  int loot;
  int item1;
  int item2;
  char name[20];
}Game;

void ChooseW(Game **p, int b) {
  int d = 0;
  for (int i = 0; i < 7; i++) {
    for (int j = 0; j < 7; j++) {
      if ((*(*(p + i) + j)).type == 1) {
        if ((*(*(p + i) + j)).class == b) {
          d = 1;
          printf(" Choose a weapon\n 1 - Torch\n 2 - Shield\n 3 - Axe\n 4 - "
                 "Bow\n ");
          scanf("%d", &(*(*(p + i) + j)).weapon);
          while ((*(*(p + i) + j)).weapon < 1 || 4 < (*(*(p + i) + j)).weapon) {
            printf("Impossible\n");
            printf(" Choose a weapon\n 1 - Torch\n 2 - Shield\n 3 - Axe\n 4 - "
                   "Bow\n ");
            scanf("%d", &(*(*(p + i) + j)).weapon);
          }
        }
      }
    }
  }
}