#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct {
  int type;
  int weapon;
  int class;
  int lab;
  int loot;
  int item1;
  int item2;
  char name[20];
}Game;

void ChooseW(Game **p, int b) {
  int d = 0;
  for (int i = 0; i < 7; i++) {
    for (int j = 0; j < 7; j++) {
      if ((*(*(p + i) + j)).type == 1) {
        if ((*(*(p + i) + j)).class == b) {
          d = 1;
          printf(" Choose a weapon\n 1 - Torch\n 2 - Shield\n 3 - Axe\n 4 - "
                 "Bow\n ");
          scanf("%d", &(*(*(p + i) + j)).weapon);
          while ((*(*(p + i) + j)).weapon < 1 || 4 < (*(*(p + i) + j)).weapon) {
            printf("Impossible\n");
            printf(" Choose a weapon\n 1 - Torch\n 2 - Shield\n 3 - Axe\n 4 - "
                   "Bow\n ");
            scanf("%d", &(*(*(p + i) + j)).weapon);
          }
        }
      }
    }
  }
}

int Totem( Game **pa, Game **pb, int c, Game **pd, int g, int h) {
  int a, b, e, d;
  e = 0;
  a = 0;
  b = 0;
  d = 0;
  for (int i = 0; i < 7; i++) {
    if (d == 1) {
      break;
    }
    for (int j = 0; j < 7; j++) {
      if (d == 1) {
        break;
      }
      if ((*(*(pb + i) + j)).type == 1) {
        if ((*(*(pb + i) + j)).class == c) {
          d = 1;
          printf("You found a Totem\n");
          printf("Choose the line of the case to transmute:\n");
          scanf("%d", &a);
          printf("Choose the column of the case to transmute:\n");
          scanf("%d", &b);
          while (a < 1 || a > 5 || b < 1 || b > 5 ||
                 (*(*(pa + a) + b)).type == 5 || (*(*(pa + a) + b)).type == 1 ||
                 (*(*(pa + a) + b)).type == 0) {
            printf("Impossible\n");
            printf("Choose of the line of the case to transmute:\n");
            scanf("%d", &a);
            printf("Choose of the column of the case to transmute:\n");
            scanf("%d", &b);
          }
          (*(*(pd + g) + h)) = (*(*(pd + a) + b));
          (*(*(pd + a) + b)) = (*(*(pa + g) + h));
          e = 1;
        }
      }
    }
  }
  return e;
}
int Teleport( Game **pa,  Game **pb, int c, Game **pd) {
  int a, b, e, d;
  e = 0;
  a = 0;
  b = 0;
  d = 0;
  for (int i = 0; i < 7; i++) {
    if (d == 1) {
      break;
    }
    for (int j = 0; j < 7; j++) {
      if (d == 1) {
        break;
      }
      if ((*(*(pb + i) + j)).type == 1) {
        if ((*(*(pb + i) + j)).class == c) {
          d = 1;
          printf("You found a portal\n");
          printf("Choose the line of the case to teleport:\n");
          scanf("%d", &a);
          printf("Choose the column of the case to teleport:\n");
          scanf("%d", &b);
          while (a < 1 || a > 5 || b < 1 || b > 5) {
            printf("Impossible\n");
            printf("Choose the line of the case to teleport:\n");
            scanf("%d", &a);
            printf("Choose the column of the case to teleport:\n");
            scanf("%d", &b);
          }
          ChooseW(pb, c);
          if ((*(*(pa + a) + b)).type == 5) {
            (*(*(pb + a) + b)) = (*(*(pb + i) + j));
            (*(*(pa + a) + b)) = (*(*(pb + i) + j));
            (*(*(pb + i) + j)).type = 5;
            (*(*(pa + i) + j)).type = 5;
          }
          if ((*(*(pa + a) + b)).type == 0) {
            printf("Impossible");
          }
          if ((*(*(pa + a) + b)).type == 1) {
            printf("Impossible");
          }
          if ((*(*(pa + a) + b)).type == 3) {
            if ((*(*(pa + a) + b)).lab == 1) {
              if ((*(*(pb + i) + j)).weapon == 2) {
                printf("A Basilisk has been defeated\n");
                (*(*(pb + a) + b)) = (*(*(pb + i) + j));
                (*(*(pa + a) + b)) = (*(*(pb + i) + j));
                (*(*(pb + i) + j)).type = 5;
                (*(*(pa + i) + j)).type = 5;

              } else {
                printf("A Basilisk defeated you\n");
                e = 1;
              }
            }
            if ((*(*(pa + a) + b)).lab == 2) {
              if ((*(*(pb + i) + j)).weapon == 3) {
                printf("A Troll has been defeated\n");
                (*(*(pb + a) + b)) = (*(*(pb + i) + j));
                (*(*(pa + a) + b)) = (*(*(pb + i) + j));
                (*(*(pb + i) + j)).type = 5;
                (*(*(pa + i) + j)).type = 5;

              } else {
                printf("A Troll defeated you\n");
                e = 1;
              }
            }
            if ((*(*(pa + a) + b)).lab == 4) {
              if ((*(*(pb + i) + j)).weapon == 1) {
                printf("A Zombie has been defeated\n");
                (*(*(pb + a) + b)) = (*(*(pb + i) + j));
                (*(*(pa + a) + b)) = (*(*(pb + i) + j));
                (*(*(pb + i) + j)).type = 5;
                (*(*(pa + i) + j)).type = 5;

              } else {
                printf("A Zombie defeated you\n");
                e = 1;
              }
            }
            if ((*(*(pa + a) + b)).lab == 5) {
              if ((*(*(pb + i) + j)).weapon == 4) {
                printf("A Harpy has been defeated\n");
                (*(*(pb + a) + b)) = (*(*(pb + i) + j));
                (*(*(pa + a) + b)) = (*(*(pb + i) + j));
                (*(*(pb + i) + j)).type = 5;
                (*(*(pa + i) + j)).type = 5;
              } else {
                printf("A Harpy defeated you\n");
                e = 1;
              }
            }
            if ((*(*(pa + a) + b)).lab == 3) {
              e = Teleport(pa, pb, c, pd);
              (*(*(pb + a) + b)).type = 5;
              (*(*(pa + a) + b)).type = 5;
            }
            if ((*(*(pa + a) + b)).lab == 6) {
              e = Totem(pa, pb, c, pd, a, b);
            }
          }
          if ((*(*(pa + a) + b)).type == 4) {
            if ((*(*(pa + a) + b)).loot == 1) {
              printf("You found the Pet Control Stick\n");
              if ((*(*(pb + i) + j)).class == 1) {
                (*(*(pb + i) + j)).item1 = 1;
              }
              (*(*(pb + a) + b)) = (*(*(pb + i) + j));
              (*(*(pa + a) + b)) = (*(*(pb + i) + j));
              (*(*(pb + i) + j)).type = 5;
              (*(*(pa + i) + j)).type = 5;
            }
            if ((*(*(pa + a) + b)).loot == 2) {
              printf("You found the Sleep Dagger\n");
              if ((*(*(pb + i) + j)).class == 3) {
                (*(*(pb + i) + j)).item1 = 1;
              }
              (*(*(pb + a) + b)) = (*(*(pb + i) + j));
              (*(*(pa + a) + b)) = (*(*(pb + i) + j));
              (*(*(pb + i) + j)).type = 5;
              (*(*(pa + i) + j)).type = 5;
            }
            if ((*(*(pa + a) + b)).loot == 3) {
              printf("You found the Fire Sword\n");
              if ((*(*(pb + i) + j)).class == 2) {
                (*(*(pb + i) + j)).item1 = 1;
              }
              (*(*(pb + a) + b)) = (*(*(pb + i) + j));
              (*(*(pa + a) + b)) = (*(*(pb + i) + j));
              (*(*(pb + i) + j)).type = 5;
              (*(*(pa + i) + j)).type = 5;
            }
            if ((*(*(pa + a) + b)).loot == 4) {
              printf("You found the Forbidden Grimoire\n");
              if ((*(*(pb + i) + j)).class == 4) {
                (*(*(pb + i) + j)).item1 = 1;
              }
              (*(*(pb + a) + b)) = (*(*(pb + i) + j));
              (*(*(pa + a) + b)) = (*(*(pb + i) + j));
              (*(*(pb + i) + j)).type = 5;
              (*(*(pa + i) + j)).type = 5;
            }
            if ((*(*(pa + a) + b)).loot == 5) {
              printf("You found a Treasure\n");
              (*(*(pb + i) + j)).item2 = 1;
              (*(*(pb + a) + b)) = (*(*(pb + i) + j));
              (*(*(pa + a) + b)) = (*(*(pb + i) + j));
              (*(*(pb + i) + j)).type = 5;
              (*(*(pa + i) + j)).type = 5;
            }
          }
        }
      }
    }
  }
  return e;
}