#ifndef H_GAME
#define H_GAME

struct Game;

#endif