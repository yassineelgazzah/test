#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct {
  int type;
  int weapon;
  int class;
  int lab;
  int loot;
  int item1;
  int item2;
  char name[20];
}Game;

Game **fill( Game **p, Game **pa) {
  pa = malloc(7 * sizeof(Game));
  *pa = malloc(sizeof(Game));
  for (int i = 0; i < 7; i++) {
    *(pa + i) = malloc(7 * sizeof(Game));
    for (int j = 0; j < 7; j++) {
      (*(*(pa + i) + j)) = (*(*(p + i) + j));
    }
  }
  return pa;
}

void createM(Game **p, Game **pa) {
  srand(time(NULL));
  printf("\n");
  int k = 0;
  int a;
  int b;
  for (int i = 0; i < 7; i++) {
    for (int j = 0; j < 7; j++) {
      if ((*(*(p + i) + j)).type == 2) {
        (*(*(pa + i) + j)).type = 2;
      } else {
        (*(*(pa + i) + j)).type = (*(*(p + i) + j)).type;
      }
    }
  }
  while (k != 19) {
    a = 1 + rand() % 5;
    b = 1 + rand() % 5;
    if ((*(*(pa + a) + b)).type == 2) {
      (*(*(pa + a) + b)).type = 3;
      (*(*(pa + a) + b)).lab = 0;
      k = k + 1;
    }
  }
  k = 0;
  while (k != 4) {
    a = 1 + rand() % 5;
    b = 1 + rand() % 5;
    if ((*(*(pa + a) + b)).type == 3) {
      if ((*(*(pa + a) + b)).lab == 0) {
        (*(*(pa + a) + b)).lab = 1;
        k = k + 1;
      }
    }
  }
  k = 0;
  while (k != 4) {
    a = 1 + rand() % 5;
    b = 1 + rand() % 5;
    if ((*(*(pa + a) + b)).type == 3) {
      if ((*(*(pa + a) + b)).lab == 0) {
        (*(*(pa + a) + b)).lab = 2;
        k = k + 1;
      }
    }
  }
  k = 0;
  while (k != 4) {
    a = 1 + rand() % 5;
    b = 1 + rand() % 5;
    if ((*(*(pa + a) + b)).type == 3) {
      if ((*(*(pa + a) + b)).lab == 0) {
        (*(*(pa + a) + b)).lab = 4;
        k = k + 1;
      }
    }
  }
  k = 0;
  while (k != 4) {
    a = 1 + rand() % 5;
    b = 1 + rand() % 5;
    if ((*(*(pa + a) + b)).type == 3) {
      if ((*(*(pa + a) + b)).lab == 0) {
        (*(*(pa + a) + b)).lab = 5;
        k = k + 1;
      }
    }
  }
  k = 0;
  while (k != 2) {
    a = 1 + rand() % 5;
    b = 1 + rand() % 5;
    if ((*(*(pa + a) + b)).type == 3) {
      if ((*(*(pa + a) + b)).lab == 0) {
        (*(*(pa + a) + b)).lab = 6;
        k = k + 1;
      }
    }
  }
  k = 0;
  while (k != 1) {
    a = 1 + rand() % 5;
    b = 1 + rand() % 5;
    if ((*(*(pa + a) + b)).type == 3) {
      if ((*(*(pa + a) + b)).lab == 0) {
        (*(*(pa + a) + b)).lab = 3;
        k = k + 1;
      }
    }
  }
  k = 0;
  while (k != 6) {
    a = 1 + rand() % 5;
    b = 1 + rand() % 5;
    if ((*(*(pa + a) + b)).type == 2) {
      (*(*(pa + a) + b)).type = 4;
      (*(*(pa + a) + b)).loot = 0;
      k = k + 1;
    }
  }
  k = 0;
  while (k != 2) {
    a = 1 + rand() % 5;
    b = 1 + rand() % 5;
    if ((*(*(pa + a) + b)).type == 4) {
      if ((*(*(pa + a) + b)).loot == 0) {
        (*(*(pa + a) + b)).loot = 5;
        k = k + 1;
      }
    }
  }
  k = 0;
  while (k != 4) {
    a = 1 + rand() % 5;
    b = 1 + rand() % 5;
    if ((*(*(pa + a) + b)).type == 4) {
      if ((*(*(pa + a) + b)).loot == 0) {
        (*(*(pa + a) + b)).loot = k + 1;
        k = k + 1;
      }
    }
  }

  for (int i = 0; i < 7; i++) {
    for (int j = 0; j < 7; j++) {
      if ((*(*(pa + i) + j)).type == 2) {
        (*(*(pa + i) + j)).type = 5;
      }
    }
  }
}

void createJ( Game **p) {
  (*(*p + 4)).class = 1;
  (*(*(p + 2))).class = 2;
  (*(*(p + 6) + 2)).class = 3;
  (*(*(p + 4) + 6)).class = 4;
  (*(*p + 4)).item1 = 0;
  (*(*(p + 2))).item1 = 0;
  (*(*(p + 6) + 2)).item1 = 0;
  (*(*(p + 4) + 6)).item1 = 0;
  (*(*p + 4)).item2 = 0;
  (*(*(p + 2))).item2 = 0;
  (*(*(p + 6) + 2)).item2 = 0;
  (*(*(p + 4) + 6)).item2 = 0;
}

Game **create( Game **p) {
  p = malloc(7 * sizeof(Game));
  *p = malloc(sizeof(Game));
  for (int i = 0; i < 7; i++) {
    *(p + i) = malloc(7 * sizeof(Game));
    for (int j = 0; j < 7; j++) {
      (*(*(p + i) + j)).type = 2;
    }
  }
  (*(*p + 4)).type = 1;
  (*(*(p + 2))).type = 1;
  (*(*(p + 6) + 2)).type = 1;
  (*(*(p + 4) + 6)).type = 1;
  for (int i = 0; i < 7; i++) {
    if ((*(*p + i)).type == 2) {
      (*(*p + i)).type = 0;
    }
  }
  for (int i = 0; i < 7; i++) {
    if ((*(*(p + i))).type == 2) {
      (*(*(p + i))).type = 0;
    }
  }
  for (int i = 0; i < 7; i++) {
    if ((*(*(p + 6) + i)).type == 2) {
      (*(*(p + 6) + i)).type = 0;
    }
  }
  for (int i = 0; i < 7; i++) {
    if ((*(*(p + i) + 6)).type == 2) {
      (*(*(p + i) + 6)).type = 0;
    }
  }
  return p;
}