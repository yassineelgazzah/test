#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <ctype.h>
#include <unistd.h>

void empty_buffer(){
  while (getchar() != '\n' );
}