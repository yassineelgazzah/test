#ifndef H_C
#define H_C
struct Game;
struct Game **fill( struct Game **p, struct Game **pa);
void createM(struct Game **p, struct Game **pa);
struct Game **create( struct Game **p);
void createJ( struct Game **p);
#endif